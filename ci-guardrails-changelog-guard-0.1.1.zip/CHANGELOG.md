# Changelog

## 0.1.1 - 2026-02-02
- Automated release bundle generated for CI Guardrails - Changelog Guard.

